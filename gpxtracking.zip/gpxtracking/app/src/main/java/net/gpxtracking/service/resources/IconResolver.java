package net.gpxtracking.service.resources;

import android.graphics.drawable.Drawable;

/**
 * Resolver for finding button icons.
 *
 *
 */
public interface IconResolver {

	/**
	 * @param key Key for icon
	 * @return The {@link Drawable} for the key.
	 */
	public Drawable getIcon(String key);
	
}
